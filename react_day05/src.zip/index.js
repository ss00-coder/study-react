import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
// import './map/expert/user.css';
// import App from './App';
import reportWebVitals from './reportWebVitals';
import App from './redux/App';
import { Provider } from 'react-redux';
import { devToolsEnhancer } from 'redux-devtools-extension';
// import Mount from './component/class/Mount';
// import SideEffect from './component/function/side-effect/SideEffect';
// import Mount from './component/function/side-effect/Mount';
// import ProductContainer from './component/function/memoization/ProductContainer';
// import ParentContainer from './context/ParentContainer';
// import App from './context/task/App';
// import LifecycleContainer from './component/class/LifecycleContainer';
// import Sounds from './state/basic/Sounds';
// import Color from './state/basic/Color';
// import Name from './ref/Name';
// import Check from './ref/Check';
// import CheckBox from './ref/CheckBox';
// import FoodContainer from './state/expert/FoodContainer';
// import Form from './custom-hook/Form';
// import FoodContainer from './map/basic/FoodContainer';
// import UserContainer from './map/expert/UserContainer';
// import Jsx06 from './jsx/Jsx06';
// import Count from './state/basic/Count';
// import Jsx02 from './jsx/Jsx02';
// import Jsx03 from './jsx/Jsx03';
// import Jsx04 from './jsx/Jsx04';
// import Container from './props/Container';
// import Jsx05 from './jsx/Jsx05';
// import Jsx01 from './jsx/Jsx01';
import { legacy_createStore as createStore } from "redux";
import count from './redux/modules/count';

const root = ReactDOM.createRoot(document.getElementById('root'));
const store = createStore(count, devToolsEnhancer());
root.render(
  // <React.StrictMode>
  <>
    {/* <App /> */}
    {/* <Jsx01 /> */}
    {/* <Jsx02 /> */}
    {/* <Jsx03 /> */}
    {/* <Jsx04 /> */}
    {/* <Jsx05 /> */}
    {/* <Container /> */}
    {/* <FoodContainer /> */}
    {/* <UserContainer /> */}
    {/* <Jsx06 /> */}
    {/* <Count /> */}
    {/* <Sounds /> */}
    {/* <Color /> */}
    {/* <Name /> */}
    {/* <Check /> */}
    {/* <CheckBox /> */}
    {/* <FoodContainer /> */}
    {/* <Form /> */}
    {/* <LifecycleContainer /> */}
    {/* <Mount /> */}
    {/* <SideEffect /> */}
    {/* <Mount /> */}
    {/* <ProductContainer /> */}
    {/* <ParentContainer /> */}
    {/* <App /> */}
    <Provider store={store}>
      <App />
    </Provider>
    </>
  // </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
