import React from 'react';

// 사용자에게 입력받은 폰트 사이즈로
// "재미있는 리덕스! 😂" 폰트 크기 변경

const FontSizeContainer = () => {
  return (
    <div>
      
    </div>
  );
};

export default FontSizeContainer;