import React from 'react';
import Counter from '../components/Counter';

const CounterContainer = () => {
  return (
    <div>
      <Counter />
    </div>
  );
};

export default CounterContainer;