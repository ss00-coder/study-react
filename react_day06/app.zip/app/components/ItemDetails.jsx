import React from 'react';
import ItemDetail from './ItemDetail';

const ItemDetails = () => {
  return (
    <div className="item-detail">
      <ItemDetail />
    </div>
  );
};

export default ItemDetails;