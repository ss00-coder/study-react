import React from "react";
import CounterContainer from "./containers/CounterContainer";

const App = () => {
  return <CounterContainer />;
};

export default App;
