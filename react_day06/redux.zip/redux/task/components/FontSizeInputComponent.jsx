import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { useInput } from "../hooks/useInput";
import { bigger } from "../modules/fontSizeControl";

const FontSizeInputComponent = () => {
  const fontSize = useSelector((state) => state.fontSize);
  const [input, onChangeInput] = useInput("");
  const dispatch = useDispatch();
  return (
    
    <div>
      <h1 style={{ fontSize: fontSize }}>재미있는 리덕스! 😂</h1>
      <input type="text" placeholder="글자 크기를 입력하세요." onChange={onChangeInput}/>
      <button
        onClick={() => {
          dispatch(bigger(input));
        }}
      >
        커져라!
      </button>
    </div>
  );
};

export default FontSizeInputComponent;
