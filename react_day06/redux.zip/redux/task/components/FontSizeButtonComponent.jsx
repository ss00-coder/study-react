import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { bigger } from "../modules/fontSize";

const FontSizeButtonComponent = () => {
  const fontSize = useSelector((state) => state.fontSize);
  const dispatch = useDispatch();
  return (
    <div>
      <h1 style={{ fontSize: fontSize }}>재미있는 리덕스! 😂</h1>
      <button
        onClick={() => {
          dispatch(bigger());
        }}
      >
        커져라!
      </button>
    </div>
  );
};

export default FontSizeButtonComponent;
