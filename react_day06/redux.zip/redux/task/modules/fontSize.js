import { createAction, handleActions } from "redux-actions";

const BIGGER = "fontSize/BIGGER";

export const bigger = createAction(BIGGER);

const initialState = {
  fontSize: "1rem"
}

const fontSize = handleActions({
  [BIGGER]: (state, action) => ({fontSize: "2rem"})
}, initialState);

export default fontSize;