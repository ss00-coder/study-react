import { createAction, handleActions } from "redux-actions";

const BIGGER = "fontSize/BIGGER";

export const bigger = createAction(BIGGER, (fontSize) => (fontSize));

const initialState = {
  fontSize: "1rem"
}

const fontSizeControl = handleActions({
  [BIGGER]: (state, action) => ({fontSize: action.payload})
}, initialState);

export default fontSizeControl;