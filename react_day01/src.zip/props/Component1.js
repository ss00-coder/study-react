import React from 'react';

const Component1 = (props) => {
  return (
    <div>
      <h1>{props.name}님 환영합니다.</h1>
    </div>
  );
};

export default Component1;