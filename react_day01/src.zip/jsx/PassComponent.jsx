import React from "react";

const PassComponent = () => {
  const pass = "입장 가능";
  return (
    <div>
      <h1>{pass} 😎</h1>
    </div>
  );
};

export default PassComponent;
