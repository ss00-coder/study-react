import React from "react";

const GuestComponent = () => {
  return (
    <div>
      <h3>😆 비회원으로 로그인되었습니다.</h3>
    </div>
  );
};

export default GuestComponent;
