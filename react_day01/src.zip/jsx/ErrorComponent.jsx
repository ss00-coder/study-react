import React from "react";

const ErrorComponent = () => {
  const error = "입장 불가";
  return (
    <div>
      <h1>{error} 😫</h1>
    </div>
  );
};

export default ErrorComponent;
