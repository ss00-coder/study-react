import React from 'react';

const Jsx02 = () => {
  const name = "리액트";

  return (
    <div>
      <h2>안녕 {name}! 😊</h2>
    </div>
  );
};

export default Jsx02;