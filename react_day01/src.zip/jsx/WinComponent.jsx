import React from "react";

const WinComponent = () => {
  const win = "당첨";
  return (
    <div>
      <h2>{win} 🎊</h2>
    </div>
  );
};

export default WinComponent;
