import React from "react";

const Food = ({name}) => {
  return <li>{name}</li>;
};

export default Food;
