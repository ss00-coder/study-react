import React from 'react';

// 사용자가 입력한 이름이 실시간으로 나올 수 있게 출력

const Name = () => {
  return (
    <div>
      
    </div>
  );
};

export default Name;