import React from 'react';

// 빨간색 버튼 누르면 글자색 빨갛게.
// 파란색 버튼 누르면 글자색 파랗게.





// 핑크색 입력 시 글자색 핑크색으로.
// 초기화 버튼을 눌러서 input태그에 입력한 문구 없애기

const Color = () => {
  return (
    <div>
      <span>즐거운 리액트~! 😍</span>
    </div>
  );
};

export default Color;