import React from 'react';

const Jsx06 = () => {
  return (
    <div>
      {/* <img src={process.env.PUBLIC_URL + '/images/icon1.png'} alt='아이콘'/> */}
      <img src={'/images/icon1.png'} alt='아이콘'/>
    </div>
  );
};

export default Jsx06;