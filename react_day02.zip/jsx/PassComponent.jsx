import React from "react";

const PassComponent = ({pass}) => {
  
  return (
    <div>
      <h1>{pass} 😎</h1>
    </div>
  );
};

export default PassComponent;
