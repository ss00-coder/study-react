import React from "react";

const WinComponent = ({win}) => {
  
  return (
    <div>
      <h2>{win} 🎊</h2>
    </div>
  );
};

export default WinComponent;
